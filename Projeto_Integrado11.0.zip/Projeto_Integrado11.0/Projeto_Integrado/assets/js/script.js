// Menu Lateral (Abrir/Fechar)
const menuBtn = document.getElementById('menu-btn');
const sidebar = document.getElementById('sidebar');
const closeBtn = document.getElementById('close-btn');

menuBtn.addEventListener('click', () => {
    sidebar.classList.add('open');
});

closeBtn.addEventListener('click', () => {
    sidebar.classList.remove('open');
});

// Lógica do Acordeão (Expansão dos Tópicos por Período)
document.addEventListener('DOMContentLoaded', () => {
    const accordionButtons = document.querySelectorAll('.accordion-button');

    accordionButtons.forEach(button => {
        button.addEventListener('click', () => {
            const contentId = button.getAttribute('data-periodo');
            const content = document.getElementById(contentId);
            
            // Alterna a classe 'active' no conteúdo e no botão
            content.classList.toggle('active');
            button.classList.toggle('active');

            // Fecha outros menus abertos (para que apenas um fique aberto por vez)
            accordionButtons.forEach(otherButton => {
                const otherContentId = otherButton.getAttribute('data-periodo');
                const otherContent = document.getElementById(otherContentId);

                if (otherButton !== button && otherButton.classList.contains('active')) {
                    otherContent.classList.remove('active');
                    otherButton.classList.remove('active');
                }
            });
        });
    });
});

// Troca de linguas (não sei oque to fazendo kkkkkkkkkkkkkk)

document.addEventListener('DOMContentLoaded', () => {
    const botaoAlternarLang = document.getElementById('lang-toggle-btn');
    
    if (!botaoAlternarLang) {
        return; 
    }

    const textoLang = document.getElementById('lang-text');
    const caminhoAtual = window.location.pathname.toLowerCase();
    
    // Ve que bagulho é
    const ehAmericankkkkkkk = caminhoAtual.includes('_en.html');
 
    const EitaTopico = caminhoAtual.includes('/assets/topicos/'); 


    const nomeArquivoComExtensao = caminhoAtual.split('/').pop();
    const nomePuro = nomeArquivoComExtensao.replace('_en.html', '').replace('.html', '');

    
    if (ehAmericankkkkkkk) {
        textoLang.textContent = 'Versão em Português';
        document.documentElement.lang = 'en-US'; 
    } else {
        textoLang.textContent = 'English Version';
        document.documentElement.lang = 'pt-BR';
    }

botaoAlternarLang.addEventListener('click', (evento) => {
        evento.preventDefault();
        
        let caminhoAlvo;
        
        if (ehAmericankkkkkkk) {

            caminhoAlvo = nomePuro + '.html'; 
        } else {
''
            caminhoAlvo = nomePuro + '_en.html';
        }

        if (EitaTopico) {

            window.location.href = './' + caminhoAlvo;

        } else {

            window.location.href = './' + caminhoAlvo;
        }
    });
});
// --- Animação da "lâmpada" no logo ---
document.addEventListener('DOMContentLoaded', () => {
    const lampLogo = document.getElementById('lampLogo');
    if (!lampLogo) return;

    // Detecta o caminho certo de acordo com a página
    let basePath;
    if (window.location.pathname.includes('/topicos/')) {
        basePath = '../images/'; // subpáginas
    } else {
        basePath = './assets/images/'; // página inicial
    }

    const frames = [
        `${basePath}logo.png`,
        `${basePath}logo1.png`,
        `${basePath}logo2.png`,
        `${basePath}logo3.png`
    ];

    let currentFrame = 0;
    let intervalId;

    function animateForward() {
        clearInterval(intervalId);
        intervalId = setInterval(() => {
            if (currentFrame < frames.length - 1) {
                currentFrame++;
                lampLogo.src = frames[currentFrame];
            } else {
                clearInterval(intervalId);
            }
        }, 150);
    }

    function animateBackward() {
        clearInterval(intervalId);
        intervalId = setInterval(() => {
            if (currentFrame > 0) {
                currentFrame--;
                lampLogo.src = frames[currentFrame];
            } else {
                clearInterval(intervalId);
            }
        }, 150);
    }

    lampLogo.addEventListener('mouseenter', animateForward);
    lampLogo.addEventListener('mouseleave', animateBackward);
});
